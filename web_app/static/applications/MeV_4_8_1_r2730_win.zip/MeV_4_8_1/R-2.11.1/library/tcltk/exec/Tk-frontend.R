{
    # NOTE: This file resides in the exec directory rather than the R
    # directory  because it does not define functions but is intended to 
    # be sourced into a running R.
    library(tcltk)
    tkStartGUI()
}
